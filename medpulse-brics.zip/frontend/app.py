"""
MedPulse BRICS - Streamlit Operational Dashboard
Run with: streamlit run frontend/app.py
"""
import streamlit as st
import pandas as pd
import json
import os
import sys

# Add project root to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend.forecasting import assess_stockout_risks
from backend.rebalancer import compute_rebalancing_plan
from backend.coldchain import evaluate_telemetry
from backend.models import TelemetryReading
from backend.gemini_copilot import GeminiSupplyChainCopilot

st.set_page_config(page_title="MedPulse BRICS", layout="wide", page_icon="🏥")

st.title("🏥 MedPulse BRICS: Smart Health & Supply Chain Resilience")
st.caption("Track 3 Prototype: Build with AI — Code for Communities | Powered by Google Gemini & Cloud")

tab1, tab2, tab3, tab4 = st.tabs(["📊 Stockout Forecast", "❄️ Cold-Chain Guard", "🔄 Stock Rebalancer", "🤖 Gemini Copilot"])

with tab1:
    st.subheader("Predictive Essential Medicine Stockout Risk")
    risks = assess_stockout_risks()
    df_risks = pd.DataFrame([r.dict() for r in risks])
    st.dataframe(df_risks[["risk_level", "facility_name", "drug_name", "current_stock", "daily_burn_rate", "estimated_days_remaining", "recommended_action"]])

with tab2:
    st.subheader("Cold-Chain IoT Anomaly Evaluator")
    temp = st.slider("Simulate Transit Temp (°C)", -5.0, 35.0, 14.5)
    sku = st.selectbox("Select Drug", ["DRUG-VAC-01 (Rabies Vaccine)", "DRUG-INS-02 (Insulin)", "DRUG-OXY-03 (Oxytocin)"])
    if st.button("Evaluate Telemetry"):
        reading = TelemetryReading(
            shipment_id="SIM-SHP-001",
            facility_id="FAC-IND-002",
            sku=sku.split()[0],
            timestamp="2026-09-30T10:00:00Z",
            temperature_c=temp,
            humidity_pct=65.0,
            shock_g=0.5,
            battery_pct=88.0,
            latitude=27.55,
            longitude=76.63
        )
        alert = evaluate_telemetry(reading, sku, 2.0, 8.0)
        if alert.severity == "BREACH_CRITICAL":
            st.error(f"CRITICAL BREACH: {alert.degradation_pct}% Quality Loss! {alert.recommended_protocol}")
        elif alert.severity == "BREACH_WARNING":
            st.warning(f"WARNING: {alert.degradation_pct}% Quality Loss. {alert.recommended_protocol}")
        else:
            st.success("NOMINAL: Cargo safe within thermal thresholds.")

with tab3:
    st.subheader("Dynamic Inter-Facility Rebalancing Recommendations")
    plans = compute_rebalancing_plan()
    for p in plans:
        st.info(f"**{p.transfer_id}**: {p.quantity} units of {p.drug_name} | {p.source_facility_name} ➔ {p.target_facility_name} ({p.estimated_transit_hours} hrs, Cold Safe: {p.cold_chain_safe})")

with tab4:
    st.subheader("Gemini Healthcare Emergency Copilot")
    prompt = st.text_area("Epidemiological Alert or Procurement Query", "Heatwave alert in Rajasthan district; stray dog bite reports spiking.")
    if st.button("Analyze with Gemini"):
        copilot = GeminiSupplyChainCopilot()
        res = copilot.analyze_health_alert(prompt, "India")
        st.json(res)
