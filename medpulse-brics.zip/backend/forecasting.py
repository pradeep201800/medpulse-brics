import json
import os
from datetime import datetime, timedelta
from typing import List
from backend.models import StockoutRiskAssessment

def load_data():
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    with open(os.path.join(base_dir, "data", "facilities.json"), "r") as f:
        facilities = json.load(f)
    with open(os.path.join(base_dir, "data", "inventory.json"), "r") as f:
        inventory = json.load(f)
    return {fac["id"]: fac for fac in facilities}, inventory

def assess_stockout_risks() -> List[StockoutRiskAssessment]:
    facility_map, inventory = load_data()
    assessments = []

    for drug in inventory:
        sku = drug["sku"]
        drug_name = drug["name"]
        
        for fac_id, stock_info in drug["facilities"].items():
            fac = facility_map.get(fac_id, {"name": fac_id})
            current_stock = stock_info["current_stock"]
            daily_burn = stock_info["daily_burn_rate"]
            lead_time = stock_info.get("lead_time_days", 5)

            days_remaining = round(current_stock / daily_burn, 1) if daily_burn > 0 else 999.0
            stockout_dt = datetime.now() + timedelta(days=days_remaining)
            stockout_date_str = stockout_dt.strftime("%Y-%m-%d")

            # Risk level determination based on days remaining vs lead time
            if days_remaining <= lead_time:
                risk_level = "CRITICAL"
                action = f"Immediate emergency rebalance or spot procurement required! Stockout in {days_remaining} days vs {lead_time} days lead time."
            elif days_remaining <= (lead_time * 1.8):
                risk_level = "HIGH"
                action = f"Trigger priority replenishment order to regional depot within 24 hours."
            elif days_remaining <= (lead_time * 3.0):
                risk_level = "MODERATE"
                action = "Schedule regular replenishment in next standard dispatch cycle."
            else:
                risk_level = "LOW"
                action = "Optimal buffer stock maintained."

            assessments.append(StockoutRiskAssessment(
                facility_id=fac_id,
                facility_name=fac["name"],
                sku=sku,
                drug_name=drug_name,
                current_stock=current_stock,
                daily_burn_rate=daily_burn,
                estimated_days_remaining=days_remaining,
                projected_stockout_date=stockout_date_str,
                risk_level=risk_level,
                recommended_action=action
            ))

    # Sort descending by risk priority
    priority_order = {"CRITICAL": 0, "HIGH": 1, "MODERATE": 2, "LOW": 3}
    assessments.sort(key=lambda x: (priority_order[x.risk_level], x.estimated_days_remaining))
    return assessments
