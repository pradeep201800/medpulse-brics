import json
import os
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from typing import List, Dict, Any
from backend.models import (
    StockoutRiskAssessment, TelemetryReading, ColdChainAlert, 
    RebalanceRecommendation, CopilotQuery
)
from backend.forecasting import assess_stockout_risks
from backend.coldchain import evaluate_telemetry
from backend.rebalancer import compute_rebalancing_plan
from backend.gemini_copilot import GeminiSupplyChainCopilot

app = FastAPI(
    title="MedPulse BRICS — Smart Health & Supply Chain Resilience Engine",
    description="Track 3 Prototype: Build with AI - Code for Communities (BRICS)",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

copilot = GeminiSupplyChainCopilot()

@app.get("/")
def read_root():
    return {
        "project": "MedPulse BRICS",
        "track": "Track 3 — Smart Health & Supply Chain Resilience",
        "hackathon": "Build with AI: Code for Communities — Second Edition",
        "status": "Operational",
        "documentation": "/docs",
        "api_endpoints": [
            "/api/facilities",
            "/api/inventory",
            "/api/stockout-risks",
            "/api/cold-chain/evaluate",
            "/api/rebalance-plan",
            "/api/copilot/analyze-alert",
            "/api/copilot/generate-rfq"
        ]
    }

@app.get("/api/facilities")
def get_facilities():
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    with open(os.path.join(base_dir, "data", "facilities.json"), "r") as f:
        return json.load(f)

@app.get("/api/inventory")
def get_inventory():
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    with open(os.path.join(base_dir, "data", "inventory.json"), "r") as f:
        return json.load(f)

@app.get("/api/stockout-risks", response_model=List[StockoutRiskAssessment])
def get_stockout_risks():
    return assess_stockout_risks()

@app.post("/api/cold-chain/evaluate", response_model=ColdChainAlert)
def evaluate_sensor_telemetry(reading: TelemetryReading):
    # Lookup drug limits
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    with open(os.path.join(base_dir, "data", "inventory.json"), "r") as f:
        inventory = json.load(f)
    
    drug = next((item for item in inventory if item["sku"] == reading.sku), None)
    drug_name = drug["name"] if drug else "Pharmaceutical Agent"
    min_temp = drug["min_temp_c"] if drug else 2.0
    max_temp = drug["max_temp_c"] if drug else 8.0

    return evaluate_telemetry(reading, drug_name, min_temp, max_temp)

@app.get("/api/rebalance-plan", response_model=List[RebalanceRecommendation])
def get_rebalance_plan():
    return compute_rebalancing_plan()

@app.post("/api/copilot/analyze-alert")
def copilot_analyze_alert(query: CopilotQuery):
    return copilot.analyze_health_alert(query.prompt, query.target_country or "India")

@app.post("/api/copilot/generate-rfq")
def copilot_generate_rfq(payload: Dict[str, Any]):
    sku = payload.get("sku", "DRUG-VAC-01")
    drug_name = payload.get("drug_name", "Rabies Vaccine")
    qty = payload.get("quantity", 500)
    city = payload.get("destination_city", "New Delhi")
    country = payload.get("country", "India")
    return copilot.generate_procurement_rfq(sku, drug_name, qty, city, country)
