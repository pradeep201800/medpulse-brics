from datetime import datetime
from typing import List, Tuple
from backend.models import TelemetryReading, ColdChainAlert

# Arrhenius kinetic estimation for thermal degradation of biologics / vaccines
def calculate_degradation(temp_c: float, min_temp_c: float, max_temp_c: float, duration_minutes: float = 30.0) -> Tuple[float, str]:
    if min_temp_c <= temp_c <= max_temp_c:
        return 0.0, "NOMINAL"
    
    # Excursion above upper threshold
    if temp_c > max_temp_c:
        delta = temp_c - max_temp_c
        # Cumulative quality loss rate accelerates with temperature difference
        degradation_pct = min(100.0, round(delta * 2.5 * (duration_minutes / 60.0), 2))
        severity = "BREACH_CRITICAL" if degradation_pct > 15.0 or temp_c > (max_temp_c + 8.0) else "BREACH_WARNING"
        return degradation_pct, severity
    
    # Excursion below freezing (critical danger for liquid vaccines due to crystal formation)
    if temp_c < min_temp_c:
        delta = min_temp_c - temp_c
        degradation_pct = min(100.0, round(delta * 4.0 * (duration_minutes / 60.0), 2))
        severity = "BREACH_CRITICAL" if temp_c < 0.0 else "BREACH_WARNING"
        return degradation_pct, severity

    return 0.0, "NOMINAL"

def evaluate_telemetry(reading: TelemetryReading, drug_name: str, min_temp_c: float, max_temp_c: float) -> ColdChainAlert:
    deg_pct, severity = calculate_degradation(reading.temperature_c, min_temp_c, max_temp_c)
    
    if severity == "BREACH_CRITICAL":
        protocol = "EMERGENCY: Immediate quarantine of shipment upon arrival. Execute Shake Test / potency bioassay before clinical dispatch."
    elif severity == "BREACH_WARNING":
        protocol = "WARNING: Prioritize usage within 48 hours or transfer to secondary active-cooling carrier."
    else:
        protocol = "PASS: Integrity verified within standard WHO/BRICS cold-chain thermal envelope."

    return ColdChainAlert(
        alert_id=f"ALT-{reading.shipment_id[-4:]}-{int(datetime.now().timestamp())}",
        shipment_id=reading.shipment_id,
        sku=reading.sku,
        drug_name=drug_name,
        temperature_c=reading.temperature_c,
        min_temp_c=min_temp_c,
        max_temp_c=max_temp_c,
        severity=severity,
        degradation_pct=deg_pct,
        timestamp=reading.timestamp,
        recommended_protocol=protocol
    )
