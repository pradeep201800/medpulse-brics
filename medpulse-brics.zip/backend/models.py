from pydantic import BaseModel, Field
from typing import List, Dict, Optional, Any
from datetime import datetime

class Facility(BaseModel):
    id: str
    name: str
    country: str
    city: str
    facility_type: str
    capacity_beds: int
    cold_storage_type: str
    latitude: float
    longitude: float

class InventoryItem(BaseModel):
    sku: str
    name: str
    category: str
    min_temp_c: float
    max_temp_c: float
    unit: str
    facilities: Dict[str, Dict[str, Any]]

class StockoutRiskAssessment(BaseModel):
    facility_id: str
    facility_name: str
    sku: str
    drug_name: str
    current_stock: int
    daily_burn_rate: float
    estimated_days_remaining: float
    projected_stockout_date: str
    risk_level: str  # "CRITICAL", "HIGH", "MODERATE", "LOW"
    recommended_action: str

class TelemetryReading(BaseModel):
    shipment_id: str
    facility_id: str
    sku: str
    timestamp: str
    temperature_c: float
    humidity_pct: float
    shock_g: float
    battery_pct: float
    latitude: float
    longitude: float

class ColdChainAlert(BaseModel):
    alert_id: str
    shipment_id: str
    sku: str
    drug_name: str
    temperature_c: float
    min_temp_c: float
    max_temp_c: float
    severity: str  # "BREACH_CRITICAL", "BREACH_WARNING", "NOMINAL"
    degradation_pct: float
    timestamp: str
    recommended_protocol: str

class RebalanceRecommendation(BaseModel):
    transfer_id: str
    sku: str
    drug_name: str
    source_facility_id: str
    source_facility_name: str
    target_facility_id: str
    target_facility_name: str
    quantity: int
    estimated_transit_hours: float
    cold_chain_safe: bool
    rationale: str

class CopilotQuery(BaseModel):
    prompt: str
    context_type: Optional[str] = "epidemic_alert"  # "epidemic_alert", "procurement_rfq", "customs_guideline"
    target_country: Optional[str] = "India"
