import json
import os
import math
from typing import List
from backend.models import RebalanceRecommendation

def haversine_distance_km(lat1, lon1, lat2, lon2):
    R = 6371.0 # Earth radius in km
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat / 2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return round(R * c, 1)

def compute_rebalancing_plan() -> List[RebalanceRecommendation]:
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    with open(os.path.join(base_dir, "data", "facilities.json"), "r") as f:
        facilities = {fac["id"]: fac for fac in json.load(f)}
    with open(os.path.join(base_dir, "data", "inventory.json"), "r") as f:
        inventory = json.load(f)

    recommendations = []
    transfer_counter = 101

    for drug in inventory:
        sku = drug["sku"]
        drug_name = drug["name"]
        
        deficits = []
        surpluses = []

        for fac_id, stock in drug["facilities"].items():
            current = stock["current_stock"]
            burn = stock["daily_burn_rate"]
            lead = stock.get("lead_time_days", 5)
            days = current / burn if burn > 0 else 999.0
            
            # Deficit: less than lead time + 1 day
            if days <= (lead + 1):
                needed = int(math.ceil((lead * 2 - days) * burn))
                deficits.append({"id": fac_id, "days": days, "needed": needed})
            # Surplus: more than 15 days of stock
            elif days >= 15:
                spare = int(math.floor((days - 10) * burn))
                if spare > 20:
                    surpluses.append({"id": fac_id, "days": days, "spare": spare})

        for deficit in deficits:
            target_fac = facilities.get(deficit["id"])
            if not target_fac:
                continue

            # Find closest surplus facility in the same country
            best_source = None
            min_dist = float("inf")

            for surplus in surpluses:
                source_fac = facilities.get(surplus["id"])
                if source_fac and source_fac["country"] == target_fac["country"] and surplus["spare"] > 0:
                    dist = haversine_distance_km(source_fac["latitude"], source_fac["longitude"],
                                                 target_fac["latitude"], target_fac["longitude"])
                    if dist < min_dist:
                        min_dist = dist
                        best_source = (surplus, source_fac)

            if best_source:
                surplus_obj, source_fac = best_source
                qty_to_transfer = min(deficit["needed"], surplus_obj["spare"])
                surplus_obj["spare"] -= qty_to_transfer
                
                transit_hours = round(min_dist / 45.0, 1) # Avg rural/inter-city transport 45 km/h
                cold_safe = transit_hours <= 12.0 # Standard phase-change cooling box endurance

                recommendations.append(RebalanceRecommendation(
                    transfer_id=f"TRF-{transfer_counter}",
                    sku=sku,
                    drug_name=drug_name,
                    source_facility_id=source_fac["id"],
                    source_facility_name=source_fac["name"],
                    target_facility_id=target_fac["id"],
                    target_facility_name=target_fac["name"],
                    quantity=qty_to_transfer,
                    estimated_transit_hours=transit_hours,
                    cold_chain_safe=cold_safe,
                    rationale=f"Transfer {qty_to_transfer} units across {min_dist} km ({transit_hours} hrs) to prevent imminent stockout at {target_fac['name']} while keeping {source_fac['name']} above safety buffer."
                ))
                transfer_counter += 1

    return recommendations
