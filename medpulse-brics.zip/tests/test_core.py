import unittest
from backend.forecasting import assess_stockout_risks
from backend.rebalancer import compute_rebalancing_plan
from backend.coldchain import evaluate_telemetry
from backend.models import TelemetryReading
from backend.gemini_copilot import GeminiSupplyChainCopilot

class TestCoreModules(unittest.TestCase):
    def test_stockout_risks(self):
        risks = assess_stockout_risks()
        self.assertGreater(len(risks), 0)
        self.assertTrue(any(r.risk_level == "CRITICAL" for r in risks))

    def test_rebalancer(self):
        plans = compute_rebalancing_plan()
        self.assertGreater(len(plans), 0)
        for p in plans:
            self.assertGreater(p.quantity, 0)
            self.assertNotEqual(p.source_facility_id, p.target_facility_id)

    def test_coldchain_nominal(self):
        reading = TelemetryReading(
            shipment_id="SHP-2026-001",
            facility_id="FAC-IND-001",
            sku="DRUG-VAC-01",
            timestamp="2026-09-30T10:00:00Z",
            temperature_c=4.5,
            humidity_pct=55.0,
            shock_g=0.2,
            battery_pct=92.0,
            latitude=28.5,
            longitude=77.2
        )
        alert = evaluate_telemetry(reading, "Rabies Vaccine", 2.0, 8.0)
        self.assertEqual(alert.severity, "NOMINAL")
        self.assertEqual(alert.degradation_pct, 0.0)

    def test_coldchain_breach(self):
        reading = TelemetryReading(
            shipment_id="SHP-2026-002",
            facility_id="FAC-IND-002",
            sku="DRUG-VAC-01",
            timestamp="2026-09-30T10:00:00Z",
            temperature_c=18.5,
            humidity_pct=75.0,
            shock_g=2.1,
            battery_pct=40.0,
            latitude=27.5,
            longitude=76.6
        )
        alert = evaluate_telemetry(reading, "Rabies Vaccine", 2.0, 8.0)
        self.assertEqual(alert.severity, "BREACH_CRITICAL")
        self.assertGreater(alert.degradation_pct, 10.0)

    def test_copilot(self):
        copilot = GeminiSupplyChainCopilot()
        res = copilot.analyze_health_alert("Severe canine bite increase in district", "India")
        self.assertEqual(res["analysis_status"], "SUCCESS")
        self.assertGreater(len(res["high_risk_categories"]), 0)

        rfq = copilot.generate_procurement_rfq("DRUG-VAC-01", "Rabies Vaccine", 1000, "New Delhi", "India")
        self.assertEqual(rfq["item_specification"]["requisition_quantity"], 1000)

if __name__ == "__main__":
    unittest.main()
